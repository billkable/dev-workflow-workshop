package com.vmware.education.tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TrackerApplicationTests {

    @Test
    public void contextLoads() {
    }

}
